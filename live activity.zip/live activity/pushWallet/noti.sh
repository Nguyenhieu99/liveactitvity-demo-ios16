#!/bin/bash

DEVICE_ID="801acab80ce604ec1253da7f7a936557b6a333e94d0b548ca6921342ce8ca2d2e4508c511dcdde534342d45ff0c6478c82e27d7ed0d1e1c772047a3e0296e87d33ee1bd55048672a52d18436998896c9"
KEY_FILE="/Users/manhhiu/Downloads/pushWallet/AuthKey_TST36Y4X42.p8"
AUTH_KEY_ID="TST36Y4X42"
TEAM_ID="QVEQ57W733"
BUNDLE_ID="vn.vnpay.smartacccount"
ENDPOINT=https://api.sandbox.push.apple.com:443

# --------------------------------------------------------------------------

base64() {
   openssl base64 -e -A | tr -- '+/' '-_' | tr -d =
}

sign() {
   printf "$1"| openssl dgst -binary -sha256 -sign "$KEY_FILE" | base64
}

time=$(date +%s)
header=$(printf '{ "alg": "ES256", "kid": "%s" }' "$AUTH_KEY_ID" | base64)
claims=$(printf '{ "iss": "%s", "iat": %d }' "$TEAM_ID" "$time" | base64)
jwt="$header.$claims.$(sign $header.$claims)"

time_str=$(date -Iseconds)
curl --verbose \
   --header "authorization: bearer $jwt" \
    --header "content-type: application/json" \
    --header "apns-push-type: liveactivity" \
   --header "apns-topic: vn.vnpay.smartacccount.push-type.liveactivity" \
   --header "apns-priority: 10" \
   --data '{
      "aps": {
        "timestamp": '$(date +%s)',
        "event": "update",
        "content-state": {
            "status": 3,
            "title_notifi": "Đang trong hành trình",
            "desc_notifi": "Vui lòng cho chúng tôi biết đánh giá của quý khách về chuyến đi",
            "distance": 0.4,
            "paymentStt": "3",
            "minute": 5,
            "estimatedTime": "17:15"
            }
        }
    }' \
   $ENDPOINT/3/device/$DEVICE_ID
