//
//  WidgetDemoBundle.swift
//  WidgetDemo
//
//  Created by Anh Nguyen on 30/08/2023.
//

import WidgetKit
import SwiftUI

@main
struct WidgetDemoBundle: WidgetBundle {
    var body: some Widget {
        WidgetDemo()
        WidgetDemoLiveActivity()
        CountLiveActivity()
    }
}
