//
//  WidgetDemoAttributes.swift
//  F5SmartAccount
//
//  Created by Anh Nguyen on 30/08/2023.
//

import ActivityKit
import WidgetKit

struct WidgetDemoAttributes: ActivityAttributes {
    public typealias VNTaxiStatus = ContentState
    
    public struct ContentState: Codable, Hashable {
        // Dynamic stateful properties about your activity go here!
        var estimatedTime: Int // thời gian dự kiến đến nơi
        var status: Int // trạng thái của cuốc
    }

    // Fixed non-changing properties about your activity go here!
    var driverName: String // Tên tài xế
    var carNumber: String // Biển số xe
    var vendorCar: String // Hãng xe
    var startAddess: String // Điểm đi
    var endAddress: String // Điểm đến
}


struct CountAttributes: ActivityAttributes {
    public typealias CountStatus = ContentState
    
    public struct ContentState: Codable, Hashable {
        // Dynamic stateful properties about your activity go here!
        var count: Int 
    }
}
