//
//  WidgetDemoLiveActivity.swift
//  WidgetDemo
//
//  Created by Anh Nguyen on 30/08/2023.
//

import ActivityKit
import WidgetKit
import SwiftUI

struct CountLiveActivity: Widget {
    var body: some WidgetConfiguration {
        ActivityConfiguration(for: CountAttributes.self) { context in
            // Lock screen/banner UI goes here
            Text("Count = \(context.state.count)")
                .font(.custom("Roboto", size: 20))
        } dynamicIsland: { context in
            DynamicIsland {
                // Expanded UI goes here.  Compose the expanded UI through
                // various regions, like leading/trailing/center/bottom
                DynamicIslandExpandedRegion(.leading) {
                    Text("Leading")
                }
                DynamicIslandExpandedRegion(.trailing) {
                    Text("Trailing")
                }
                DynamicIslandExpandedRegion(.bottom) {
                    Text("Bottom")
                    // more content
                }
            } compactLeading: {
                Text("L")
            } compactTrailing: {
                Text("T")
            } minimal: {
                Text("Min")
            }
            .widgetURL(URL(string: "http://www.apple.com"))
            .keylineTint(Color.red)
        }
    }
}

struct WidgetDemoLiveActivity: Widget {
    fileprivate func tripView(_ context: ActivityViewContext<WidgetDemoAttributes>) -> some View {
        return // Lock screen/banner UI goes here
        VStack(alignment: .leading) {
            HStack() {
                Image("logo_login")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(height: 30, alignment: .leading)
                Spacer()
                Image("bmw")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(height: 60, alignment: .trailing)
            }
            HStack() {
                VStack(alignment: .leading) {
                    if context.state.status == 1 { // tài xế nhận cuốc
                        Text("Tài xế \(context.attributes.driverName) đang đến")
                            .font(.custom("Roboto", size: 15))
                        Text("Dự kiến đón bạn trong \(context.state.estimatedTime) phút nữa")
                            .font(.custom("Roboto", size: 11))
                            .foregroundColor(.red)
                    } else if context.state.status == 2 { // tài xế đã đến
                        Text("Tài xế \(context.attributes.driverName) đã đến nơi, mời bạn xuống xe")
                            .font(.custom("Roboto", size: 15)).lineLimit(2)
                    } else if context.state.status == 3 { // bạn đang trong hành trình
                        Text("Bạn đang trong hành trình đến \(context.attributes.endAddress)")
                            .font(.custom("Roboto", size: 15)).lineLimit(2)
                        Text("Dự kiến \(context.state.estimatedTime) phút nữa sẽ đến nơi")
                            .font(.custom("Roboto", size: 11))
                            .foregroundColor(.red)
                    } else if context.state.status == 4 { // chuyến đi kết thúc
                        Text("Hành trình từ \(context.attributes.startAddess) đến \(context.attributes.endAddress) đã kết thúc")
                            .font(.custom("Roboto", size: 15))
                        Text("Cảm ơn bạn đã lựa chọn VNTaxi ^_^")
                            .font(.custom("Roboto", size: 11))
                            .foregroundColor(.red)
                    }
                }
                Spacer()
                VStack(alignment: .trailing) {
                    Text("\(context.attributes.carNumber)")
                        .font(.headline)
                    Text("\(context.attributes.vendorCar)")
                        .font(.custom("Roboto", size: 14))
                }
            }.padding(EdgeInsets(top: -10, leading: 0, bottom: 0, trailing: 0))
            ZStack {
                RoundedRectangle(cornerRadius: 3)
                    .fill(.secondary).frame(height: 6)
                HStack {
                    if context.state.status == 1 { // tài xế nhận cuốc
                        RoundedRectangle(cornerRadius: 3)
                            .fill(.green)
                            .frame(width: 100, height: 6)
                    } else if context.state.status == 2 { // tài xế đã đến
                        RoundedRectangle(cornerRadius: 3)
                            .fill(.green)
                            .frame(height: 6)
                    } else if context.state.status == 3 { // bạn đang trong hành trình
                        RoundedRectangle(cornerRadius: 3)
                            .fill(.green)
                            .frame(width: 50, height: 6)
                    } else if context.state.status == 4 { // chuyến đi kết thúc
                        
                    }
                    Image("taxi")
                        .resizable()
                        .frame(width: 35, height: 35, alignment: .leading)
                        .padding(EdgeInsets(top: 0, leading: -10, bottom: 5, trailing: 0))
                    Spacer()
                    Image("location-pin")
                        .resizable()
                        .frame(width: 25, height: 25, alignment: .leading)
                        .padding(EdgeInsets(top: 0, leading: 0, bottom: 10, trailing: -10))
                }
            }
        }.padding(10)
    }
    
    var body: some WidgetConfiguration {
        ActivityConfiguration(for: WidgetDemoAttributes.self) { context in
            tripView(context)
        } dynamicIsland: { context in
            DynamicIsland {
                // Expanded UI goes here.  Compose the expanded UI through
                // various regions, like leading/trailing/center/bottom
                DynamicIslandExpandedRegion(.center, priority: .leastNormalMagnitude) {
                    tripView(context)
                }
            } compactLeading: {
                Image("logo30PxViVnpay")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
            } compactTrailing: {
                Text("6 min")
                    .font(.custom("Roboto", size: 14))
                    .foregroundColor(.red)
            } minimal: {
                Image("logo30PxViVnpay")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
            }
            .widgetURL(URL(string: "http://www.apple.com"))
            .keylineTint(Color.red)
        }
    }
}

struct WidgetDemoLiveActivity_Previews: PreviewProvider {
    static let attributes = WidgetDemoAttributes(driverName: "Tony",
                                                 carNumber: "29Y7407.21",
                                                 vendorCar: "Yamaha",
                                                 startAddess: "22 Láng Hạ",
                                                 endAddress: "138 Trần Bình")
    static let contentState = WidgetDemoAttributes.ContentState(estimatedTime: 5, status: 1)

    static var previews: some View {
        attributes
            .previewContext(contentState, viewKind: .dynamicIsland(.compact))
            .previewDisplayName("Island Compact")
        attributes
            .previewContext(contentState, viewKind: .dynamicIsland(.expanded))
            .previewDisplayName("Island Expanded")
        attributes
            .previewContext(contentState, viewKind: .dynamicIsland(.minimal))
            .previewDisplayName("Minimal")
        attributes
            .previewContext(contentState, viewKind: .content)
            .previewDisplayName("Notification")
    }
}
