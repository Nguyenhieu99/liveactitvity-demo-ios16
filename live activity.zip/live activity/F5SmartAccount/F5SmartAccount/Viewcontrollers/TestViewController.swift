//
//  TestViewController.swift
//  F5SmartAccount
//
//  Created by Anh Nguyen on 30/08/2023.
//

import UIKit
import ActivityKit
import VNLiveActivitiesSDK

class TestViewController: UIViewController {

    @IBOutlet weak var tokenLabel: UITextView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func didSelectStartCountLive(_ sender: Any) {
//        if ActivityAuthorizationInfo().areActivitiesEnabled {
//            let attributes = CountAttributes()
//            let contentState = CountAttributes.ContentState(count: 1)
//            do {
//                let deliveryActivity = try Activity<CountAttributes>.request(
//                    attributes: attributes,
//                    contentState: contentState,
//                    pushType: .token)
//                print("Requested a count Live Activity \(deliveryActivity.id).")
//                Task {
//                    for await pushToken in deliveryActivity.pushTokenUpdates {
//                        print("pushToken = \(pushToken)")
//                        let pushTokenString = pushToken.map {String(format: "%02x", $0)}.joined()
//                        print(pushTokenString)
//                    }
//                }
//            } catch (let error) {
//                print("Error requesting count Live Activity \(error.localizedDescription).")
//            }
//        }
        if #available(iOS 16.1, *) {
            let task = Task {
                await VNLiveActivitiesManagers.shared.createTaxiLiveActivity()
            }
        }
    }


    @IBAction func didSelectStart(_ sender: Any) {
        if ActivityAuthorizationInfo().areActivitiesEnabled {
            let attributes = WidgetDemoAttributes(driverName: "Nguyễn Văn A",
                                                  carNumber: "30H9-99999",
                                                  vendorCar: "BMW X5 2023",
                                                  startAddess: "22 Láng Hạ",
                                                  endAddress: "138 Trần Bình")
            let contentState = WidgetDemoAttributes.VNTaxiStatus(estimatedTime: 5, status: 1)
            do {
                let deliveryActivity = try Activity<WidgetDemoAttributes>.request(
                    attributes: attributes,
                    contentState: contentState,
                    pushType: .token)
                print("Requested a taxi Live Activity \(deliveryActivity.id).")
                Task {
                    for await pushToken in deliveryActivity.pushTokenUpdates {
                        print("pushToken = \(pushToken)")
                        let pushTokenString = pushToken.reduce("") { $0 + String(format: "%02x", $1) }
                        print(pushTokenString)
                    }
                }
            } catch (let error) {
                print("Error requesting taxi Live Activity \(error.localizedDescription).")
            }
        }
    }
    
    @IBAction func driverIncome(_ sender: Any) {
        Task {
            let updatedDeliveryStatus = WidgetDemoAttributes.VNTaxiStatus(estimatedTime: 5, status: 2)
            
            for activity in Activity<WidgetDemoAttributes>.activities{
                await activity.update(using: updatedDeliveryStatus)
            }

            print("Updated Live Activity")
        }
    }
    
    @IBAction func journeyStart(_ sender: Any) {
        Task {
            let updatedDeliveryStatus = WidgetDemoAttributes.VNTaxiStatus(estimatedTime: 25, status: 3)
            
            for activity in Activity<WidgetDemoAttributes>.activities{
                await activity.update(using: updatedDeliveryStatus)
            }

            print("Updated Live Activity")
        }
    }
    
     @IBAction func journeyEnd(_ sender: Any) {
         Task {
             let updatedDeliveryStatus = WidgetDemoAttributes.VNTaxiStatus(estimatedTime: 0, status: 4)
             
             for activity in Activity<WidgetDemoAttributes>.activities{
                 await activity.update(using: updatedDeliveryStatus)
             }

             print("Updated Live Activity")
         }
     }

    
    func endActivity() {
        Task {
            for activity in Activity<WidgetDemoAttributes>.activities{
                // nếu default: The Live Activity will be updated with the final data and will be on the screen for some more time. The system will close the activity when the user sees the new data or at most 4 hours later, whichever comes first.
                await activity.end(dismissalPolicy: .immediate)
            }
            print("End Live Activity")
        }
    }
}
