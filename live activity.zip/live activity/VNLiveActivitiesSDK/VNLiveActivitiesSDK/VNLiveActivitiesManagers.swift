//
//  VNLiveActivitiesManagers.swift
//  VNLiveActivitiesSDK
//
//  Created by ManhHiu on 3/6/24.
//

import Foundation
import UIKit
import ActivityKit

public class VNLiveActivitiesManagers: NSObject {
    public static let shared = VNLiveActivitiesManagers()
    
    @available(iOS 16.1, *)
    public func createTaxiLiveActivity() async -> String? {
        let attributes = VNTaxiSDKWidgetAttributes(
            destination: "22 Láng Hạ, Đống Đa, Hà Nội",
            vehicleType: 0,
            license_plate: "88C1-34485",
            type_car: "Taxi 4 chỗ",
            service_provider: "Xanh SM")
        
        let contentState = VNTaxiSDKWidgetAttributes.ContentState(status: 1, title_notifi: "Đã có tài xế nhận", desc_notifi: "Tài xế đang trên đường tới", distance: 0, paymentStt: "", minute: 0, estimatedTime: "")
        do {
            let activity = try Activity<VNTaxiSDKWidgetAttributes>.request(
                attributes: attributes,
                contentState: contentState,
                pushType: .token)
            for await data in activity.pushTokenUpdates {
                let myToken = data.map {String(format: "%02x", $0)}.joined()
                print("token live activity: \(myToken)")
                return myToken
            }
        } catch (let error) {
            print(error.localizedDescription)
            return nil
        }
        return nil
    }
    
    @available(iOS 16.1, *)
    public func endActivity() {
        Task {
            if (Activity<VNTaxiSDKWidgetAttributes>.activities.count > 0) {
                for activity in Activity<VNTaxiSDKWidgetAttributes>.activities{
                    //Default: The Live Activity will be updated with the final data and will be on the screen for some more time. The system will close the activity when the user sees the new data or at most 4 hours later, whichever comes first.
                    await activity.end(dismissalPolicy: .immediate)
                }
            } else {
                // Fallback on earlier versions
            }
            print("End Live Activity")
        }
    }
    
    
    @available(iOS 16.1, *)
    public func getAttributes() -> VNTaxiSDKWidgetAttributes {
        return VNTaxiSDKWidgetAttributes(
            destination: "22 Láng Hạ, Đống Đa, Hà Nội",
            vehicleType: 0,
            license_plate: "88C1-34485",
            type_car: "Taxi 4 chỗ",
            service_provider: "Xanh SM"
        )
    }
    //
}
