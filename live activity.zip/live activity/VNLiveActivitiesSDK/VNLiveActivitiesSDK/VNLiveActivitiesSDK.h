//
//  VNLiveActivitiesSDK.h
//  VNLiveActivitiesSDK
//
//  Created by ManhHiu on 3/6/24.
//

#import <Foundation/Foundation.h>

//! Project version number for VNLiveActivitiesSDK.
FOUNDATION_EXPORT double VNLiveActivitiesSDKVersionNumber;

//! Project version string for VNLiveActivitiesSDK.
FOUNDATION_EXPORT const unsigned char VNLiveActivitiesSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <VNLiveActivitiesSDK/PublicHeader.h>


