//
//  VNLiveAcitivitiesSDKLiveActivity.swift
//  VNLiveAcitivitiesSDK
//
//  Created by ManhHiu on 3/14/24.
//

import ActivityKit
import WidgetKit
import SwiftUI

struct VNLiveAcitivitiesSDKAttributes: ActivityAttributes {
    public struct ContentState: Codable, Hashable {
        // Dynamic stateful properties about your activity go here!
        var emoji: String
    }

    // Fixed non-changing properties about your activity go here!
    var name: String
}

struct VNTaxiSDKWidgetLiveActivity: Widget {
    @Environment(\.colorScheme) var colorScheme
    fileprivate func tripInView(_ context: ActivityViewContext<VNTaxiSDKWidgetAttributes>) -> some View {
        return
        VStack(alignment: .leading) {
            VStack(alignment: .leading, spacing: 0) {
                HStack {
                    Image("logo")
                        .resizable()
                        .frame(width: 82, height: 24)
                    Spacer()
                    if (context.attributes.vehicleType == 0) {
                        if (context.state.status == 8 || context.state.paymentStt == "0") {
                            Image("car_big_icon_error")
                                .resizable()
                                .frame(width: 60, height: 46)
                        } else {
                            Image("car_big_icon")
                                .resizable()
                                .frame(width: 60, height: 46)
                        }
                    } else {
                        if (context.state.status == 8 || context.state.paymentStt == "0") {
                            Image("bike_big_icon_error")
                                .resizable()
                                .frame(width: 30, height: 30)
                        } else {
                            Image("bike_big_icon")
                                .resizable()
                                .frame(width: 30, height: 30)
                        }
                    }
                }
                .padding(.top, 0)
                .padding(.trailing, 15)
                .padding(.leading, 15)
                .padding(.bottom, 0)
                HStack {
                    VStack(alignment: .leading, spacing: 0) {
                        Text(context.state.title_notifi)
                            .font(.system(size: 16))
                            .bold()
                        if (context.state.status == 3) {
                            HStack {
                                Image("destination")
                                    .resizable()
                                    .frame(width: 16, height: 16)
                                Text("Tới \(context.attributes.destination) vào khoảng \(context.state.estimatedTime)")
                                    .font(.system(size: 13))
                                    .lineLimit(2)
                                    .fixedSize(horizontal: false, vertical: true)
                            }
                        } else {
                            Text(context.state.desc_notifi)
                                .font(.system(size: 13))
                                .lineLimit(2)
                                .fixedSize(horizontal: false, vertical: true)
                            Spacer()
                        }
                    }
                    Spacer()
                    if (context.state.status <= 4 && context.state.paymentStt != "0") {
                        VStack(alignment: .trailing) {
                            Text(context.attributes.license_plate)
                                .font(.system(size: 16))
                                .bold()
                            Text(context.attributes.service_provider)
                                .font(.system(size: 13))
                            Spacer()
                        }
                    }
                }
                .padding(.top, 0)
                .padding(.trailing, 15)
                .padding(.leading, 15)
                .padding(.bottom, 0)
                
                if (context.state.status == 5) {
                    //To do
                } else if (context.state.status == 6) {
                    //To do
                } else if (context.state.status == 8) {
                    //To do
                } else {
                    if (context.state.paymentStt != "0" || context.state.status < 4) {
                        GeometryReader { geo in
                            ZStack(alignment: .leading) {
                                RoundedRectangle(cornerRadius: 15)
                                    .fill(.secondary)
                                    .frame(height: 3)
                                    .padding(.trailing, 10)
                                HStack(spacing:0) {
                                    if (context.state.distance >= 0 && context.state.distance <= 1) {
                                        if (context.state.distance <= 0.6) {
                                            RoundedRectangle(cornerRadius: 15)
                                                .fill(.blue)
                                                .frame(width: context.state.distance * (geo.size.width - 30), height: 3)
                                        } else {
                                            RoundedRectangle(cornerRadius: 15)
                                                .fill(.blue)
                                                .frame(width: context.state.distance * (geo.size.width - 30) - 30 - 16, height: 3)
                                        }
                                    } else if (context.state.distance < 0) {
                                        RoundedRectangle(cornerRadius: 15)
                                            .fill(.blue)
                                            .frame(width: 0 * (geo.size.width - 30), height: 3)
                                    } else if (context.state.distance > 1) {
                                        RoundedRectangle(cornerRadius: 15)
                                            .fill(.blue)
                                            .frame(width: 1 * (geo.size.width - 30) - 30 - 16, height: 3)
                                    }
                                    if context.attributes.vehicleType == 0 {
                                        Image("car")
                                            .resizable()
                                            .frame(width: 30, height: 30)
                                    } else {
                                        Image("bike")
                                            .resizable()
                                            .frame(width: 30, height: 30)
                                    }
                                    Spacer()
                                    Image("circle_blue")
                                        .resizable()
                                        .frame(width: 16, height: 16, alignment: .trailing)
                                        .padding(.trailing, 0)
                                }
                            }
                        }
                        .padding(.top, 0)
                        .padding(.trailing, 15)
                        .padding(.leading, 15)
                        .padding(.bottom, 10)
                    }
                }
            }
            Spacer()
            if (context.state.status >= 4) {
                if (context.state.paymentStt == "0") {
                    GeometryReader { geo in
                        ZStack {
                            PaymentView(title: "Truy cập ứng dụng")
                                .frame(width: geo.size.width, height: 40)
                        }
                        .background(Color(red: 68/255, green: 101/255, blue: 240/255))
                    }
                    .frame(height: 40)
                    .padding(.bottom, 0)
                } else {
                    if (context.state.status == 5) {
                            GeometryReader { geo in
                                ZStack {
                                    PaymentView(title: "Thanh toán ngay")
                                        .frame(width: geo.size.width, height: 40)
                                }
                                .background(Color(red: 68/255, green: 101/255, blue: 240/255))
                            }
                            .frame(height: 40)
                            .padding(.bottom, 0)
                    } else if (context.state.status == 6) {
                            GeometryReader { geo in
                                VStack(alignment: .center) {
                                    Image("5stars")
                                        .resizable()
                                        .frame(width: 148, height: 20)
                                        .padding(.leading, (geo.size.width - 148)/2)
                                }
                            }.padding(.bottom, 25)
                    } else if (context.state.status == 8) {
                            GeometryReader { geo in
                                ZStack {
                                    PaymentView(title: "Truy cập ứng dụng")
                                        .frame(width: geo.size.width, height: 40)
                                }
                                .background(Color(red: 68/255, green: 101/255, blue: 240/255))
                            }
                            .frame(height: 40)
                            .padding(.bottom, 0)
                    }
                }
            }
        }
        .ignoresSafeArea()
        .padding(.top, 0)
        .padding(.bottom, 0)
        .padding(.trailing, 0)
        .padding(.leading, 0)
    }
    
    var body: some WidgetConfiguration {
        ActivityConfiguration(for: VNTaxiSDKWidgetAttributes.self) { context in
            // For devices that don't support the Dynamic Island.
            tripInView(context)
        } dynamicIsland: { context in
            DynamicIsland {
                // Expanded UI goes here.  Compose the expanded UI through
                // various regions, like leading/trailing/center/bottom
                DynamicIslandExpandedRegion(.center, priority: .leastNormalMagnitude) {
                    tripInView(context)
                }
            } compactLeading: {
                Image("logoViVnpay")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
            } compactTrailing: {
                Text("\(context.state.minute) min")
                    .font(.custom("Roboto", size: 14))
            } minimal: {
                Image("logoViVnpay")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
            }
        }
    }
}

struct PaymentView: View {
    var title: String
    var body: some View {
        ZStack {
            Text(title)
                .font(.system(size: 16))
                .bold()
                .frame(height: 20, alignment: .center)
                .foregroundColor(.white)
        }.padding(0)
    }
}
