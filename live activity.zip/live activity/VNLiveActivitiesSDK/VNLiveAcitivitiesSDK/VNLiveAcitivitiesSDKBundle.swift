//
//  VNLiveAcitivitiesSDKBundle.swift
//  VNLiveAcitivitiesSDK
//
//  Created by ManhHiu on 3/14/24.
//

import WidgetKit
import SwiftUI

@main
struct VNLiveAcitivitiesSDKBundle: WidgetBundle {
    var body: some Widget {
        VNLiveAcitivitiesSDK()
    }
}
