//
//  VVLiveActivitiesSDKAttributes.swift
//  VNLiveActivitiesSDK
//
//  Created by ManhHiu on 3/14/24.
//

import Foundation
import ActivityKit

public struct VNTaxiSDKWidgetAttributes: ActivityAttributes {
    public typealias tripInfomation = ContentState

    public struct ContentState: Codable, Hashable {
        var status: Int
        var title_notifi: String
        var desc_notifi: String
        var distance: Double
        var paymentStt: String
        var minute: Int
        var estimatedTime: String
    }
    var destination: String
    var vehicleType: Int
    var license_plate: String
    var type_car: String
    var service_provider: String
}

